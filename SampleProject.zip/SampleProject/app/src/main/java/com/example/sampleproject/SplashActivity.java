package com.example.sampleproject;

import android.app.Activity;
import android.os.Bundle;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(@androidx.annotation.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
